# luapy

A Lua-inspired scripting environment for Python.

## Installation
```bash
pip install luapy